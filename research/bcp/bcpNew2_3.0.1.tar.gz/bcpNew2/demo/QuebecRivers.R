data(QuebecRivers)
bcpr.rivers <- bcp(QuebecRivers)
plot(bcpr.rivers)
