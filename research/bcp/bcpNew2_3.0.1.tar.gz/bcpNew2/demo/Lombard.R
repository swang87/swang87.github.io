data(lombard)

bcp.model <- bcp(cbind(lombard), burnin=500, mcmc=5000, return.mcmc=T)
bcpr.model <- bcp(lombard, cbind(1:100), burnin=500, mcmc=5000, return.mcmc=T)

plot(bcp.model)
plot(bcpr.model)
