#
# bcp: an R package for performing a Bayesian analysis
# of change point problems.
#
# Copyright (C) 2011 Chandra Erdman and John W. Emerson
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, a copy is available at
# http://www.r-project.org/Licenses/
#
#-------------------
# FILE: bcp.R

"bcp" <- function(y, x=NULL, id = NULL, adj=NULL, w0=NULL, p0=0.2, ba = 10, 
                  burnin=50, mcmc=500, return.mcmc=FALSE, 
                  boundaryType = "node", beta=1,
                  membinit=NULL, p1 = 1, freqAPP = 20) {

######################################################
########################### BEGIN THE WORKER FUNCTION:
######################################################

"worker.bcp" <- function(mcmc, y, x, id, w0, p0, ba, burnin, return.mcmc,
                         membinit, beta, boundaryType, adj, p1, freqAPP) {

  require(bcpNew2)

  # INITIALIZATION
#  if (is.data.frame(x)) x <- matrix(as.double(x), nrow=nrow(x), ncol=ncol(x))
#  if (is.vector(x)) x <- matrix(as.double(x), ncol=1)
#  if (!is.matrix(x)) stop("x must be a vector, matrix or a data frame")
#  if (nrow(x)==1) {
#    warning("coercing data to a single series")
#    x <- matrix(as.vector(x), ncol=1)
#  }
  if (is.null(id)) {
    if (is.matrix(y)) id <- 1:nrow(y)
    else id <- 1:length(y)
  }
  if (min(id) == 1) id <- id - 1
  if (is.null(x)) {
    # doing multivariate bcp
    if (is.null(w0)) w0 <- 0.2
    if (is.vector(y)) y <- cbind(y)
    # Do the work in C:
    if (is.null(adj)) {
      out <- .Call("rcpp_bcpM", 
        PACKAGE="bcpNew2", 
        data = y, id = as.integer(id),
        mcmcreturn = as.integer(return.mcmc),
        burnin = as.integer(burnin), 
        mcmc = as.integer(mcmc),     
        a = as.double(p0),
        w = as.double(w0))      
      class(out) <- "bcp"
      out$pchange[length(out$pchange)] <- NA     # Fix up the last position, always NA
    } else {
      out <- .Call("rcpp_ppm", 
                    PACKAGE="bcpNew2", 
                    data = y, id = as.integer(id),
                    adj = adj,
                    mcmcreturn = as.integer(return.mcmc),
                    burnin = as.integer(burnin), 
                    mcmc = as.integer(mcmc),     
                    a = as.double(p0),
                    c = as.double(w0),
                    membs = membinit, 
                    beta = beta, 
                    prioronly = as.integer(0), 
                    boundaryType = as.integer(boundaryType),
                    p1 = as.double(p1),
                    freqAPP = as.integer(freqAPP))
    }
    out$data <- cbind(id, y)
    # if (dim(out$pmean)[2] == 1) {
    #   out$posterior.mean <- as.numeric(out$pmean)
    # } else 
    out$posterior.mean <- out$pmean
  } else {
    # doing regression bcp

    if (is.vector(x)) x <- cbind(x)
    if (sum(x[,1]==1) != nrow(x)) x <- cbind(1, x) 
    if (!is.double(x)) x <- matrix(as.double(x), nrow(x), ncol(x))
     
    if (is.null(w0)) w0 <- rep(0.2, ncol(x))

    indmat <- t(sapply(unique(id), function(y) id == y)*1)
    

    # Do the work in C:
    if (is.null(adj)) {
      out <- .Call("rcpp_bcpR", 
                  PACKAGE="bcpNew2", 
                  y = as.double(y),
                  x = x,
                  indmat = indmat,
                  id = as.integer(id),
                  mcmcreturn = as.integer(return.mcmc),
                  burnin = as.integer(burnin), 
                  mcmc = as.integer(mcmc),     
                  a = as.double(p0),
                  c = as.double(w0),
                  ba = ba
                )
      out$pchange[max(id)+1] <- NA     # Fix up the last position, always NA
      out$data = cbind(id+1, y,x[,-1])
      out$posterior.mean = as.numeric(out$pmean)/table(id)
      class(out) <- "bcpR"
    } else {

      out <- .Call("rcpp_ppmR", 
                    PACKAGE="bcpNew2", 
                    y = y, x = x,                    
                    indmat = indmat,
                    id = as.integer(id), adj = adj,
                    mcmcreturn = as.integer(return.mcmc),
                    burnin = as.integer(burnin), 
                    mcmc = as.integer(mcmc),     
                    a = as.double(p0),
                    c = as.double(w0),
                    membs = membinit, 
                    beta = beta, 
                    prioronly = as.integer(0), 
                    boundaryType = as.integer(boundaryType),
                    b.a = ba,
                    p1 = as.double(p1),
                    freqAPP = as.integer(freqAPP))
      out$data = cbind(id+1, y,x)
      out$posterior.mean <- as.numeric(out$pmean)/table(id)
    }

  }
  


  out$posterior.prob <- out$pchange
  out$pchange <- out$pmean <-NULL
  return(out)
  # RETURN RESULTS
  z <- list(data=x,
    return.mcmc=return.mcmc,
#   mcmc.means=out$mcmc.means,
    mcmc.rhos=out$mcmc.rhos,
    blocks=out$blocks,
    posterior.mean=out$pmean,
#   posterior.var=out$pvar,
    posterior.prob=out$pchange,
    liks = out$lik,
    burnin=burnin,            
    mcmc=mcmc,     
    p0=p0,     
    w0=w0)     
  class(z) <- "bcp"


}

###################################################
########################### END THE WORKER FUNCTION
########################### BEGIN THE MAIN SECTION:
###################################################

# Function header and foreach setup, from above:
#
#"bcp" <- function(x, w0=0.2, p0=0.2, burnin=50, mcmc=500, return.mcmc=FALSE) {
#

  if (!is.null(adj)) {
    if (boundaryType == "node") {
      boundaryType <- 1
    } else {
      boundaryType <- 2
    }

    if (is.vector(y)) {
      dataToRank <- y
    } else if (is.matrix(y)) {
      dataToRank <- y[,1]
    }
    if (!is.null(id)) { # varying num of obs per loc, we'll sample one obs per loc to rank
      inds <- sapply(1:max(id), function(g) {
        inds <- which(id==g)
        if (length(inds)==1) return(inds)
        return(sample(inds, 1))
      })
      dataToRank <- dataToRank[inds]
    }
    numNodes <- length(dataToRank)
    if (is.null(membinit)) {
      Minit <- ceiling(sqrt(numNodes))
      o <- rank(dataToRank, ties.method="first")    
      membinit <- ceiling(o/Minit)
      membinit <- pmin(membinit, Minit)-1
    } else if (length(membinit) == 1) {
      Minit <- ceiling(numNodes/membinit)
      o <- rank(dataToRank, ties.method="first")    
      membinit <- ceiling(o/Minit)
      membinit <- pmin(membinit, Minit)-1
    } else {
      nComponents <- max(membinit)
      if (length(setdiff(unique(membinit), 1:nComponents))>0) {
        stop("Error in membinit")
      } else {
        membinit <- membinit-1
      }
    }
    relabelMap <- order(unique(membinit))
    membinit <- relabelMap[membinit+1]-1
  }
# memb <<- membinit

  require(foreach)
  if (is.null(getDoParName())) {
    registerDoSEQ() # A little hack to avoid the foreach warning 1st time.
  }

  # Divy up the work across available workers:
  numworkers <- getDoParWorkers()
  mcmc.w <- rep(floor(mcmc/numworkers), numworkers)
  if (numworkers>1) { # Give the first worker a little extra if needed.
    mcmc.w[1] <- mcmc - sum(mcmc.w[2:numworkers])
  }

  ######################################################
  # The call to do the work, perhaps in parallel:

  ans <- foreach(mcmc=mcmc.w) %dopar% {
    worker.bcp(mcmc, y=y, x=x, id=id, w0=w0, p0=p0, ba=ba, 
               burnin=burnin, return.mcmc=return.mcmc,
               membinit=membinit, beta=beta, boundaryType=boundaryType,
               adj=adj, p1=p1, freqAPP=freqAPP)
  }
  ######################################
  # Process the result and return. 
return(ans[[1]])
  gmeans <- ans[[1]]$posterior.mean
  gprob <- ans[[1]]$posterior.prob
  gvar <- ans[[1]]$posterior.var * (mcmc.w[1]-1)
  if (numworkers>1) {
    for (i in 2:numworkers) {
      gmeans <- gmeans + ans[[i]]$posterior.mean
      gprob <- gprob + ans[[i]]$posterior.prob
      gvar <- gvar + ans[[i]]$posterior.var * (mcmc.w[i]-1)
    }
    gmeans <- gmeans / numworkers
    gprob <- gprob / numworkers
  }

  # gvar at this point is the within-group SS (WSS)
  bss <- mcmc.w[1] * (ans[[1]]$posterior.mean - gmeans)^2
  if (numworkers>1) {
    for (i in 2:numworkers) {
      bss <- bss + mcmc.w[i] * (ans[[i]]$posterior.mean - gmeans)^2
    }
  }
  gvar <- gvar + bss
  gvar <- gvar / (mcmc-1)

  gbcp <- ans[[1]]
  gbcp$posterior.mean <- gmeans
  gbcp$posterior.prob <- gprob
  gbcp$posterior.var <- gvar
  gbcp$mcmc <- mcmc
  gbcp$burnin <- burnin * numworkers
  bblocks <- gbcp$blocks[1:burnin]
  allblocks <- gbcp$blocks[(burnin+1):length(gbcp$blocks)]
  if (numworkers>1) {
    for (i in 2:numworkers) {
      bblocks <- c(bblocks, ans[[i]]$blocks[1:burnin])
      allblocks <- c(allblocks, ans[[i]]$blocks[(burnin+1):length(ans[[i]]$blocks)])
    }
  }
  gbcp$blocks <- c(bblocks, allblocks)

  if (return.mcmc) {                ### Non-trivial because of multivariate as well
                                    ### as possible multiple workers...
    lastpos <- mcmc.w[1] + burnin

    # Handle the rhos, burnin and real mcmc partition states:
    mcmc.rburn <- gbcp$mcmc.rhos[,1:burnin]
    mcmc.rhos <- gbcp$mcmc.rhos[,(burnin+1):lastpos]

    nsamples <- ncol(gbcp$data)
    n <- nrow(gbcp$data)

    # Ditto for the results, but possibly multivariate:
    temp <- matrix(gbcp$mcmc.means[,1], nrow=n, ncol=lastpos)
    mcmc.mburn <- temp[,1:burnin]
    mcmc.means <- temp[,(burnin+1):lastpos]
    if (nsamples>1) {
      mcmc.mburn <- list(mcmc.mburn)
      mcmc.means <- list(mcmc.means)
      for (i in 2:nsamples) {
        temp <- matrix(gbcp$mcmc.means[,i], nrow=n, ncol=lastpos)
        mcmc.mburn[[i]] <- temp[,1:burnin]
        mcmc.means[[i]] <- temp[,(burnin+1):lastpos]
      }
    }

    if (numworkers>1) {
      for (j in 2:numworkers) {
        lastpos <- mcmc.w[j] + burnin
        temp <- matrix(ans[[j]]$mcmc.means[,1], nrow=n, ncol=lastpos)
        # if mcmc.mburn is a matrix, simply cbind stuff from the workers
        if (nsamples==1) {
          mcmc.mburn <- cbind(mcmc.mburn, temp[,1:burnin])
          mcmc.means <- cbind(mcmc.means, temp[,(burnin+1):lastpos])
        } else {
          # if mcmc.mburn is a list of matrices, do the work across samples,
          # being very careful of the list structure: a list with matrices for
          # each data series, whereas we're unpacking the worker results from
          # a worker list, as well... be very careful!
          mcmc.mburn[[1]] <- cbind(mcmc.mburn[[1]], temp[,1:burnin])
          mcmc.means[[1]] <- cbind(mcmc.means[[1]], temp[,(burnin+1):lastpos])
          for (i in 2:nsamples) {
            temp <- matrix(ans[[j]]$mcmc.means[,i], nrow=n, ncol=lastpos)
            mcmc.mburn[[i]] <- cbind(mcmc.mburn[[i]], temp[,1:burnin])
            mcmc.means[[i]] <- cbind(mcmc.means[[i]], temp[,(burnin+1):lastpos])
          }
        }
      }
    }

    if (nsamples==1) {
      gbcp$mcmc.means <- cbind(mcmc.mburn, mcmc.means)
    } else {
      gbcp$mcmc.means <- list(burnins=mcmc.mburn, means=mcmc.means)
    }
  }

  return(gbcp)

}


makeAdjGrid <- function(n,m=NULL) {
  if (is.null(m)) m <- n
  adj <- vector('list', n*m)
  
  for (i in 2:(n-1)) {
    for (j in 2:(m-1)) {
      adj[[(j-1)*n+i]] <- c((j-2)*n+(i-1):(i+1),(j-1)*n+i-c(1,-1), j*n+(i-1):(i+1))-1
    }
  }
  i <- 1
  for (j in 2:(m-1)) adj[[(j-1)*n+i]] <- c((j-2)*n+1:2, (j-1)*n+2, (j)*n+1:2)-1
  i <- n
  for (j in 2:(m-1))  adj[[(j-1)*n+i]] <- c((j-1)*n-1:0, j*n-1, (j+1)*n-1:0)-1
  j <- 1
  for (i in 2:(n-1)) adj[[(j-1)*n+i]] <- c(i-1,i+1, n+(i-1):(i+1))-1
  j <- m
  for (i in 2:(n-1)) adj[[(j-1)*n+i]] <- c((m-2)*n+(i-1):(i+1), (m-1)*n+i-1, (m-1)*n+i+1)-1
  adj[[1]] <- c(2, n+1:2)-1
  adj[[n]] <- c((1:2)*n-1,2*n)-1
  adj[[(m-1)*n+1]] <-  c((m-2)*n+1:2, (m-1)*n+2)-1
  adj[[n*m]] <- c((m-1)*n-(1:0), n*m-1)-1
  return(adj)
}

makeAdjGrid4 <- function(n,m=NULL)  {
  if (is.null(m)) m <- n
  adj <- vector('list', n*m)
  
  for (i in 2:(n-1)) {
    for (j in 2:(m-1)) {
      adj[[(j-1)*n+i]] <- c((j-2)*n+i,(j-1)*n+i-c(1,-1), j*n+i)-1
    }
  }
  i <- 1
  for (j in 2:(m-1)) adj[[(j-1)*n+i]] <- c((j-2)*n+1, (j-1)*n+2, (j)*n+1)-1
  i <- n
  for (j in 2:(m-1))  adj[[(j-1)*n+i]] <- c((j-1)*n, j*n-1, (j+1)*n)-1
  j <- 1
  for (i in 2:(n-1)) adj[[(j-1)*n+i]] <- c(i-1,i+1, n+i)-1
  j <- m
  for (i in 2:(n-1)) adj[[(j-1)*n+i]] <- c((n-2)*m+i, (n-1)*m+i-1, (n-1)*m+i+1)-1
  adj[[1]] <- c(2, n+1)-1
  adj[[n]] <- c(n-1,2*n)-1
  adj[[(m-1)*n+1]] <-  c((m-2)*n+1, (m-1)*n+2)-1
  adj[[n*m]] <- c((m-1)*n, n*m-1)-1
  return(adj)
}

