#
# bcp: an R package for performing a Bayesian analysis
# of change point problems.
#
# Copyright (C) 2011 Chandra Erdman and John W. Emerson
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, a copy is available at
# http://www.r-project.org/Licenses/
#
#-------------------
# FILE: bcp.R

"bcp" <- function(y, x=NULL, id = NULL, adj=NULL, w0=NULL, p0=0.2, ba = 10, 
                  burnin=50, mcmc=500, return.mcmc=FALSE, 
                  boundaryType = "node", p1 = 1, freqAPP = 20) {

######################################################
########################### BEGIN THE WORKER FUNCTION:
######################################################

"worker.bcp" <- function(mcmc, y, x, id, w0, p0, ba, burnin, return.mcmc, membinit,
                         boundaryType, adj, p1, freqAPP) {

  require(bcp2)

  # INITIALIZATION
#  if (is.data.frame(x)) x <- matrix(as.double(x), nrow=nrow(x), ncol=ncol(x))
#  if (is.vector(x)) x <- matrix(as.double(x), ncol=1)
#  if (!is.matrix(x)) stop("x must be a vector, matrix or a data frame")
#  if (nrow(x)==1) {
#    warning("coercing data to a single series")
#    x <- matrix(as.vector(x), ncol=1)
#  }
  if (is.null(id)) {
    if (is.matrix(y)) id <- 1:nrow(y)
    else id <- 1:length(y)
  }
  if (min(id) == 1) id <- id - 1
  if (is.null(x)) {
    # doing multivariate bcp
    if (is.null(w0)) w0 <- 0.2
    if (is.vector(y)) y <- cbind(y)
    # Do the work in C:
    if (is.null(adj)) {
      out <- .Call("rcpp_bcpM", 
        PACKAGE="bcp2", 
        data = y, id = as.integer(id),
        mcmcreturn = as.integer(return.mcmc),
        burnin = as.integer(burnin), 
        mcmc = as.integer(mcmc),     
        a = as.double(p0),
        w = as.double(w0))      
      attr(out, "structure") <- "series"
    } else {
      out <- .Call("rcpp_ppm", 
                    PACKAGE="bcp2", 
                    data = y, id = as.integer(id),
                    adj = adj,
                    mcmcreturn = as.integer(return.mcmc),
                    burnin = as.integer(burnin), 
                    mcmc = as.integer(mcmc),     
                    a = as.double(p0),
                    c = as.double(w0),
                    membs = membinit,
                    boundaryType = as.integer(boundaryType),
                    p1 = as.double(p1),
                    freqAPP = as.integer(freqAPP))
      attr(out, "structure") <- "graph"
    }
    attr(out, "model") <- "multivariate"
    out$data <- cbind(id+1, y) 
    if (is.null(colnames(x))) {
      colnames(out$posterior.mean) <- paste(rep("X", ncol(out$data)-1), 
                                   1:(ncol(out$data)-1), sep="")
    } else
      colnames(out$posterior.mean) <- colnames(x)
  } else {
    # doing regression bcp
    if (is.vector(x)) x <- cbind(x)
    if (sum(x[,1]==1) != nrow(x)) x <- cbind(1, x) 
    if (!is.double(x)) x <- matrix(as.double(x), nrow(x), ncol(x))
    if (is.null(w0)) w0 <- rep(0.2, ncol(x))

    indmat <- t(sapply(unique(id), function(y) id == y)*1)   

    # Do the work in C:
    if (is.null(adj)) {
      out <- .Call("rcpp_bcpR", 
                  PACKAGE="bcp2", 
                  y = as.double(y),
                  x = x,
                  indmat = indmat,
                  id = as.integer(id),
                  mcmcreturn = as.integer(return.mcmc),
                  burnin = as.integer(burnin), 
                  mcmc = as.integer(mcmc),     
                  a = as.double(p0),
                  c = as.double(w0),
                  ba = ba
                )
      out$data = cbind(id+1, y,x[,-1])
      attr(out, "structure") <- "series"
    } else {
      out <- .Call("rcpp_ppmR", 
                    PACKAGE="bcp2", 
                    y = y, x = x,                    
                    indmat = indmat,
                    id = as.integer(id), adj = adj,
                    mcmcreturn = as.integer(return.mcmc),
                    burnin = as.integer(burnin), 
                    mcmc = as.integer(mcmc),     
                    a = as.double(p0),
                    c = as.double(w0),
                    membs = membinit,
                    boundaryType = as.integer(boundaryType),
                    b.a = ba,
                    p1 = as.double(p1),
                    freqAPP = as.integer(freqAPP))
      out$data = cbind(id+1, y,x)
      attr(out, "structure") <- "graph"
    }
    attr(out, "model") <- "regression"
    out$posterior.mean <- cbind(as.numeric(out$posterior.mean)/table(id), out$betaposts[,1:ncol(x)])
    colnames(out$posterior.mean) <- c("y", "(Intercept)", paste("x", 1:(ncol(x)-1), sep=""))
    if (!is.null(colnames(x))) 
      colnames(out$posterior.mean)[-(1:2)] <- colnames(x)[-1]
  }
  if (attr(out, "structure") == "series") 
    out$posterior.prob[length(out$posterior.prob)] <- NA     # Fix up the last position, always NA

  # RETURN RESULTS
  z <- list(data=out$data,
    return.mcmc=return.mcmc,
    mcmc.means=out$mcmc.means,
    mcmc.rhos=out$mcmc.rhos,
    blocks=out$blocks,
    posterior.mean=out$posterior.mean,
    posterior.var=out$posterior.var,
    posterior.prob=out$posterior.prob,
    burnin=burnin,            
    mcmc=mcmc,     
    p0=p0,     
    w0=w0)     
  attr(z, "model") <- attr(out, "model")
  attr(z, "structure") <- attr(out, "structure")
  class(z) <- "bcp"
  return(z)
}

###################################################
########################### END THE WORKER FUNCTION
########################### BEGIN THE MAIN SECTION:
###################################################

# Function header and foreach setup, from above:
#
#"bcp" <- function(x, w0=0.2, p0=0.2, burnin=50, mcmc=500, return.mcmc=FALSE) {
#

  if (!is.null(adj)) {
    if (boundaryType == "node") {
      boundaryType <- 1
    } else {
      boundaryType <- 2
    }

    if (is.vector(y)) {
      dataToRank <- y
    } else if (is.matrix(y)) {
      dataToRank <- y[,1]
    }
    if (!is.null(id)) { # varying num of obs per loc, we'll sample one obs per loc to rank
      inds <- sapply(1:max(id), function(g) {
        inds <- which(id==g)
        if (length(inds)==1) return(inds)
        return(sample(inds, 1))
      })
      dataToRank <- dataToRank[inds]
    }
    numNodes <- length(dataToRank)
    # if (is.null(membinit)) {
    Minit <- ceiling(sqrt(numNodes))
    o <- rank(dataToRank, ties.method="first")    
    membinit <- ceiling(o/Minit)
    membinit <- pmin(membinit, Minit)-1
    # } else if (length(membinit) == 1) {
    #   Minit <- ceiling(numNodes/membinit)
    #   o <- rank(dataToRank, ties.method="first")    
    #   membinit <- ceiling(o/Minit)
    #   membinit <- pmin(membinit, Minit)-1
    # } else {
    #   nComponents <- max(membinit)
    #   if (length(setdiff(unique(membinit), 1:nComponents))>0) {
    #     stop("Error in membinit")
    #   } else {
    #     membinit <- membinit-1
    #   }
    # }
    relabelMap <- order(unique(membinit))
    membinit <- relabelMap[membinit+1]-1
  }

  ans <- worker.bcp(mcmc, y=y, x=x, id=id, w0=w0, p0=p0, ba=ba, 
               burnin=burnin, return.mcmc=return.mcmc,
               membinit=membinit, boundaryType=boundaryType,
               adj=adj, p1=p1, freqAPP=freqAPP)
  #  ==================================
  #  ===  Reformat the mcmc.means   ===
  #  ==================================
  if (return.mcmc) {
    if (ncol(ans$mcmc.means) > 1) {
      mcmc.means <- vector('list', ncol(ans$mcmc.means)) 
      for (i in 1:length(mcmc.means)) {
        mcmc.means[[i]] <- matrix(ans$mcmc.means[,i], nrow=burnin+mcmc, byrow=TRUE)
      }
    } else {
      mcmc.means <- matrix(ans$mcmc.means, nrow=burnin+mcmc, byrow=TRUE)
    }
    ans$mcmc.means <- mcmc.means
  } 
  return(ans)
}


makeAdjGrid <- function(n,m=NULL, k=8) {
  if (is.null(m)) m <- n
  adj <- vector('list', n*m)
  
  if (k == 8) {
    for (i in 2:(n-1)) {
      for (j in 2:(m-1)) {
        adj[[(j-1)*n+i]] <- c((j-2)*n+(i-1):(i+1),(j-1)*n+i-c(1,-1), j*n+(i-1):(i+1))-1
      }
    }
    i <- 1
    for (j in 2:(m-1)) adj[[(j-1)*n+i]] <- c((j-2)*n+1:2, (j-1)*n+2, (j)*n+1:2)-1
    i <- n
    for (j in 2:(m-1))  adj[[(j-1)*n+i]] <- c((j-1)*n-1:0, j*n-1, (j+1)*n-1:0)-1
    j <- 1
    for (i in 2:(n-1)) adj[[(j-1)*n+i]] <- c(i-1,i+1, n+(i-1):(i+1))-1
    j <- m
    for (i in 2:(n-1)) adj[[(j-1)*n+i]] <- c((m-2)*n+(i-1):(i+1), (m-1)*n+i-1, (m-1)*n+i+1)-1
    adj[[1]] <- c(2, n+1:2)-1
    adj[[n]] <- c((1:2)*n-1,2*n)-1
    adj[[(m-1)*n+1]] <-  c((m-2)*n+1:2, (m-1)*n+2)-1
    adj[[n*m]] <- c((m-1)*n-(1:0), n*m-1)-1
  } else if (k == 4) {
    for (i in 2:(n-1)) {
      for (j in 2:(m-1)) {
        adj[[(j-1)*n+i]] <- c((j-2)*n+i,(j-1)*n+i-c(1,-1), j*n+i)-1
      }
    }
    i <- 1
    for (j in 2:(m-1)) adj[[(j-1)*n+i]] <- c((j-2)*n+1, (j-1)*n+2, (j)*n+1)-1
    i <- n
    for (j in 2:(m-1))  adj[[(j-1)*n+i]] <- c((j-1)*n, j*n-1, (j+1)*n)-1
    j <- 1
    for (i in 2:(n-1)) adj[[(j-1)*n+i]] <- c(i-1,i+1, n+i)-1
    j <- m
    for (i in 2:(n-1)) adj[[(j-1)*n+i]] <- c((n-2)*m+i, (n-1)*m+i-1, (n-1)*m+i+1)-1
    adj[[1]] <- c(2, n+1)-1
    adj[[n]] <- c(n-1,2*n)-1
    adj[[(m-1)*n+1]] <-  c((m-2)*n+1, (m-1)*n+2)-1
    adj[[n*m]] <- c((m-1)*n, n*m-1)-1
  } else {
    stop("Error: k must be 4 or 8.")
  }
  return(adj)
}
